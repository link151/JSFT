angular.module('controllers',[])

.controller('indexCtrl',['$scope','$rootScope','$http','$location',
        function($scope,$rootScope, $http, $location) {
      	
//      	alert("indexCtrl");
      	 
}])